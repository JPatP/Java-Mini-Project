package model.employee;

public class Trainee {

}
