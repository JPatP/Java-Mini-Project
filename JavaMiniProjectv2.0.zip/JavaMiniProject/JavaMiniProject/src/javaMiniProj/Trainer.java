package javaMiniProj;

public class Trainer extends EmployeeModel {

	    public Trainer() {
	    }

	    public Trainer(int employeeNumber, String employeeType, String name, String contactInfo, String businessUnit, int totalPenalty, int itemsBorrowed) {
	        super(employeeNumber, employeeType, name, contactInfo, businessUnit, totalPenalty, itemsBorrowed);
	    }
	}


