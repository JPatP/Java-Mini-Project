package javaMiniProj;

import javaMiniProj.EmployeeController;
import javaMiniProj.EmployeeView;

public class Tester {

    public static void main(String[] args) {

        new EmployeeView();

    }
}

